---
name: excalidraw-board
description: Turn notes, a thought or plan into a clean one-page Excalidraw diagram (.excalidraw file). Use when asked to make an excalidraw, turn something into a board/diagram, visualise it, or map it out.
---

# Excalidraw Board

Turn the user's raw thinking into a **scannable one-page visual** plus, when warranted, a **supporting Markdown file** that holds the depth the board can't.

Core principle: **the board is the map, the MD is the territory.** The board must be readable at a glance (headline, structure, the 5–9 things that matter). Detail, evidence, reasoning, sources, and long lists go in the MD.

## When to also write a supporting MD

Always produce the board. Add a companion `.md` when the input has any of: reasoning/justification behind each point, evidence or numbers with sources, definitions, more than ~9 items in a group, or anything the user will want to *read* rather than *glance at*. A pure structural sketch (flow, org chart, quadrant, simple timeline) usually needs no MD. When unsure, ask the user, or default to board-only and offer the MD.

## Workflow

1. **Understand the thought.** Read everything the user gave — notes, an idea, a doc, prior boards they point to as a style reference. If it's thin or ambiguous about what to depict, ask 1–2 sharp questions (what's the ONE thing this board should make obvious? what are the top-level sections?). Don't invent structure the user didn't imply.

2. **Choose the shape.** Map the thought to a diagram type. Common shapes (see `reference.md` for recipes):
   - **Timeline / flow / pipeline** → `flow()` (chained boxes with arrows).
   - **Causes vs numbers / pros vs cons / before vs after** → `columns()` (side-by-side panels).
   - **Layered argument, sections, a list of grouped points** → stacked `panel()`s joined by `arrow()`.
   - **A conclusion, target, or "so what"** → `node()` at the bottom.
   - Most real boards **compose these**: title → subtitle → a flow → arrow → columns → arrow → panel → arrow → node.

3. **Assign color by meaning, not decoration.** danger=red (problems/risks), warn=yellow (metrics/watch), good=green (wins/recommendations/salvage), info=blue (targets/conclusions), action=purple (decisions/rules/next-steps), neutral=grey (context/timeline). Consistency across the board matters more than variety.

4. **Generate with the library — never hand-write JSON.** Write a short script that imports the helper and builds the board. This guarantees valid schema, unique ids, and clean vertical layout. Put the script in the scratchpad (or beside the output); the deliverable is the `.excalidraw` file, not the script.

   ```python
   import sys
   sys.path.insert(0, "/Users/kwameai/.claude/skills/excalidraw-board/lib")
   from excalidraw import Board

   b = Board(width=1400)
   b.title("TITLE — THE ONE-LINE THESIS")
   b.subtitle("the framing / the numbers that set the stakes")
   b.heading("SECTION A")
   b.flow(["Step 1", "Step 2", "Step 3", "☠ End"], color="neutral")
   b.arrow()
   b.columns([
       {"label": "LEFT",  "body": "1 point\n2 point\n3 point", "color": "danger"},
       {"label": "RIGHT", "body": "metric = x\nmetric = y",     "color": "warn"},
   ])
   b.arrow()
   b.panel("WHAT TO DO", "1 rule\n2 rule\n3 rule", color="action")
   b.arrow()
   b.node("→ THE POINT / THE TARGET", color="info")
   print(b.save("/absolute/path/to/output.excalidraw"))
   ```

   Then run it: `python3 <your-script>.py`. It prints the element count and validates the JSON (raises on duplicate ids / invalid JSON). If it doesn't print a count, fix the error before proceeding.

5. **Write the supporting MD** (if warranted) next to the board, same base name (e.g. `plan.excalidraw` + `plan.md`). Keep the board's headline/sections as the MD's headings so the two mirror each other.

6. **Verify & hand off.** Confirm the file exists and re-report the element count. Tell the user the board renders in excalidraw.com (drag-drop or File→Open), the Obsidian Excalidraw plugin, or the VS Code Excalidraw extension — you can't visually confirm rendering yourself, so ask them to open it.

## Library API (in `lib/excalidraw.py`)

- `Board(width=1400)` — canvas; manages a downward layout cursor and unique ids.
- `.title(txt)` / `.subtitle(txt)` / `.heading(txt, color=None)` — text rows.
- `.flow(items, color, per_row=None)` — boxes in a row with connector arrows; wraps into rows if many.
- `.columns([{label,body,color}, ...])` — 2–3 side-by-side panels, auto equal-width.
- `.panel(label, body, color)` — full-width colored box with heading above it (mono body).
- `.node(txt, color, width=None)` — a single centered rounded box (conclusion/target).
- `.arrow(dy=30)` — centered downward connector between sections.
- `.gap(px)` — vertical spacing.
- `.save(path)` — writes JSON, asserts unique ids, returns element count.

Body text is monospace (keeps columns aligned); titles/headings use the sketchy hand font. Full element schema, palette hex values, and more layout recipes are in `reference.md` — read it only if you need to go beyond the primitives (custom elements, exact colors, sizing).

## Rules

- Never hand-write or hand-edit the `.excalidraw` JSON. Always go through the library so ids stay unique and the schema stays valid.
- Keep the board to one screen's worth — if it's overflowing, that content belongs in the supporting MD, not more boxes.
- Use absolute paths for output. Default output location: alongside the source material the user is working with, or ask.
- Match the user's own visual grammar if they supplied an example board (colors, density, hand vs mono).
- One idea per box/line. Boards die when boxes hold paragraphs.
