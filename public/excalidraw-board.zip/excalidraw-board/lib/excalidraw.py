"""
excalidraw.py — a tiny, dependency-free helper for generating valid .excalidraw files.

Why this exists: hand-writing Excalidraw JSON is error-prone (duplicate ids, wrong
element schema, mangled coordinates). This library gives you a `Board` with a vertical
layout cursor and a handful of primitives that always emit valid, unique-id'd elements.

Usage (write a small per-board script that imports this):

    import sys
    sys.path.insert(0, "/Users/kwameai/.claude/skills/excalidraw-board/lib")
    from excalidraw import Board

    b = Board(width=1400)
    b.title("MY BOARD TITLE")
    b.subtitle("one-line framing")
    b.heading("A TIMELINE")
    b.flow(["Idea", "Build", "Sell", "☠ Dead"], color="neutral")
    b.arrow()
    b.columns([
        {"label": "PROBLEMS", "body": "1 thing\n2 thing", "color": "danger"},
        {"label": "NUMBERS",  "body": "x = 4\ny = 0",     "color": "warn"},
    ])
    b.arrow()
    b.panel("NEXT STEPS", "- do this\n- then this", color="good")
    b.arrow()
    b.node("→ THE POINT", color="info")
    n = b.save("/abs/path/out.excalidraw")
    print("wrote", n, "elements")

Design notes / gotchas:
- Body text defaults to a monospace hand font (fontFamily 3); titles/headings use the
  hand-drawn font (fontFamily 1). This matches Excalidraw's default sketchy aesthetic.
- Excalidraw RE-MEASURES text on load, so our height math only needs to be close enough
  to lay boxes out sensibly; it does not need to be pixel-perfect.
- Coordinates grow downward via an internal `y` cursor. Full-width helpers advance it
  automatically; call arrow() between sections to draw a connector and add a gap.
"""

import json

# semantic name -> (strokeColor, backgroundColor). Soft pastel bg, strong border.
PALETTE = {
    "danger":  ("#e03131", "#ffc9c9"),
    "danger2": ("#e03131", "#ffe3e3"),  # softer red (banners)
    "warn":    ("#e8590c", "#ffec99"),
    "good":    ("#2f9e44", "#b2f2bb"),
    "info":    ("#1971c2", "#a5d8ff"),
    "action":  ("#9c36b5", "#eebefa"),
    "neutral": ("#495057", "#f1f3f5"),
}

FONT_HAND = 1   # Excalifont / Virgil (sketchy) — titles & headings
FONT_MONO = 3   # Cascadia / code — body text (keeps columns aligned)

INK = "#1e1e1e"
MUTE = "#495057"


def _resolve(color):
    """Accept a palette name or an explicit (stroke, bg) tuple."""
    if color is None:
        return (INK, "transparent")
    if isinstance(color, (tuple, list)):
        return tuple(color)
    if color in PALETTE:
        return PALETTE[color]
    raise ValueError(f"unknown color {color!r}; use a (stroke,bg) tuple or one of {list(PALETTE)}")


class Board:
    def __init__(self, width=1400, left=40, top=20, bg="#ffffff"):
        self.W = width
        self.L = left
        self.inner = width - 2 * left
        self.y = top
        self.bg = bg
        self._els = []
        self._n = 1000

    # ---- low level ----
    def _id(self, p):
        self._n += 1
        return f"{p}{self._n}"

    def _base(self, **kw):
        e = dict(angle=0, strokeColor=INK, backgroundColor="transparent",
                 fillStyle="hachure", strokeWidth=2, strokeStyle="solid", roughness=1,
                 opacity=100, groupIds=[], frameId=None, roundness=None,
                 seed=self._n * 7 + 13, versionNonce=self._n * 11 + 5, isDeleted=False,
                 boundElements=[], updated=1, link=None, locked=False)
        e.update(kw)
        return e

    def _rect(self, x, y, w, h, stroke, bg, round_=True):
        self._els.append(self._base(id=self._id("r"), type="rectangle", x=x, y=y,
                         width=w, height=h, strokeColor=stroke, backgroundColor=bg,
                         roundness={"type": 3} if round_ else None))

    def _text(self, x, y, w, txt, size=15, fam=FONT_MONO, color=INK, align="left"):
        lines = txt.split("\n")
        h = int(len(lines) * size * 1.25)
        self._els.append(self._base(id=self._id("t"), type="text", x=x, y=y, width=w,
                         height=h, strokeColor=color, text=txt, fontSize=size,
                         fontFamily=fam, textAlign=align, verticalAlign="top",
                         baseline=int(h - 4), containerId=None, originalText=txt,
                         lineHeight=1.25))
        return h

    def _arrow(self, x, y, dx, dy):
        self._els.append(self._base(id=self._id("a"), type="arrow", x=float(x), y=float(y),
                         width=float(abs(dx)), height=float(abs(dy)), strokeColor="#343a40",
                         roundness={"type": 2}, points=[[0, 0], [float(dx), float(dy)]],
                         lastCommittedPoint=None, startBinding=None, endBinding=None,
                         startArrowhead=None, endArrowhead="triangle"))

    @staticmethod
    def _text_h(txt, size):
        return int(len(txt.split("\n")) * size * 1.25)

    # ---- public primitives (advance the y cursor) ----
    def title(self, txt, size=28):
        self.y += self._text(self.L, self.y, self.inner, txt, size, FONT_HAND, INK) + 6
        return self

    def subtitle(self, txt, size=16):
        self.y += self._text(self.L, self.y, self.inner, txt, size, FONT_HAND, MUTE) + 16
        return self

    def heading(self, txt, size=18, color=None):
        c = _resolve(color)[0] if color else INK
        self.y += self._text(self.L, self.y, self.inner, txt, size, FONT_HAND, c) + 6
        return self

    def gap(self, px=16):
        self.y += px
        return self

    def arrow(self, dy=30, gap=6):
        """Centered downward connector; advances the cursor past it."""
        self._arrow(self.L + self.inner / 2, self.y, 0.0, dy)
        self.y += dy + gap
        return self

    def panel(self, label, body, color="neutral", size=14, pad=14):
        """Full-width colored box (mono body) with an optional heading above it."""
        stroke, bg = _resolve(color)
        if label:
            self.y += self._text(self.L, self.y, self.inner, label, 17, FONT_HAND, stroke) + 6
        h = self._text_h(body, size) + 2 * pad
        self._rect(self.L, self.y, self.inner, h, stroke, bg)
        self._text(self.L + 16, self.y + pad, self.inner - 30, body, size, FONT_MONO, INK)
        self.y += h + 4
        return self

    def columns(self, cols, size=14, pad=14, colgap=20):
        """cols = list of {label, body, color}. Renders side-by-side equal-width panels."""
        n = len(cols)
        cw = (self.inner - (n - 1) * colgap) / n
        # headings row
        top = self.y
        for i, c in enumerate(cols):
            stroke = _resolve(c.get("color", "neutral"))[0]
            if c.get("label"):
                self._text(self.L + i * (cw + colgap), top, cw, c["label"], 17, FONT_HAND, stroke)
        head_h = 28 if any(c.get("label") for c in cols) else 0
        boxtop = top + head_h
        box_h = max(self._text_h(c["body"], size) for c in cols) + 2 * pad
        for i, c in enumerate(cols):
            x = self.L + i * (cw + colgap)
            stroke, bg = _resolve(c.get("color", "neutral"))
            self._rect(x, boxtop, cw, box_h, stroke, bg)
            self._text(x + 16, boxtop + pad, cw - 30, c["body"], size, FONT_MONO, INK)
        self.y = boxtop + box_h + 4
        return self

    def flow(self, items, color="neutral", per_row=None, box_h=54, hgap=16, rowgap=34, size=13):
        """A left-to-right chain of boxes with connector arrows. Wraps into rows."""
        stroke, bg = _resolve(color)
        n = len(items)
        if per_row is None:
            per_row = max(1, min(n, self.inner // 150))
        cw = (self.inner - (per_row - 1) * hgap) / per_row
        top = self.y
        rows = 0
        for i, it in enumerate(items):
            r, col = divmod(i, per_row)
            rows = r + 1
            x = self.L + col * (cw + hgap)
            yy = top + r * (box_h + rowgap)
            self._rect(x, yy, cw, box_h, stroke, bg)
            th = self._text_h(str(it), size)
            self._text(x, yy + (box_h - th) / 2, cw, str(it), size, FONT_MONO, INK, "center")
            if col > 0:  # right-pointing arrow in the gap before this box
                self._arrow(x - hgap + 1, yy + box_h / 2, hgap - 2, 0.0)
        self.y = top + rows * (box_h + rowgap) - (rowgap - 6)
        return self

    def node(self, txt, color="info", width=None, size=17):
        """A single centered rounded box (e.g. a conclusion / target node)."""
        stroke, bg = _resolve(color)
        w = width or min(self.inner, 720)
        x = self.L + (self.inner - w) / 2
        th = self._text_h(txt, size)
        h = th + 28
        self._rect(x, self.y, w, h, stroke, bg)
        self._text(x + 16, self.y + 14, w - 32, txt, size, FONT_MONO, INK, "center")
        self.y += h + 4
        return self

    # ---- output ----
    def to_dict(self):
        return {"type": "excalidraw", "version": 2, "source": "https://excalidraw.com",
                "elements": self._els,
                "appState": {"gridSize": 20, "viewBackgroundColor": self.bg},
                "files": {}}

    def save(self, path):
        doc = self.to_dict()
        ids = [e["id"] for e in doc["elements"]]
        assert len(ids) == len(set(ids)), "duplicate element ids"
        with open(path, "w") as f:
            json.dump(doc, f, indent=2, ensure_ascii=False)
        # re-parse to prove it's valid JSON
        with open(path) as f:
            json.load(f)
        return len(ids)


if __name__ == "__main__":  # smoke test
    b = Board()
    b.title("SMOKE TEST")
    b.subtitle("proving the lib emits valid output")
    b.flow(["A", "B", "C", "☠ D"], color="neutral")
    b.arrow()
    b.columns([{"label": "L", "body": "1\n2", "color": "danger"},
               {"label": "R", "body": "x\ny", "color": "warn"}])
    b.arrow()
    b.node("→ done", color="info")
    import tempfile, os
    p = os.path.join(tempfile.gettempdir(), "excalidraw_smoke.excalidraw")
    print("OK", b.save(p), "elements ->", p)
