"""
Worked example — a compact "project post-mortem" board that exercises every primitive.
Run:  python3 examples/example_board.py   (writes example_board.excalidraw next to it)

Copy this as a starting point, then replace the content with the user's actual thought.
The pattern (title -> subtitle -> flow -> columns -> panel -> node, joined by arrows) is
the workhorse layout for most analysis/decision/roadmap boards.
"""
import os, sys

# import the library relative to this file (works wherever the skill lives)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "lib"))
from excalidraw import Board

b = Board(width=1400)

b.title("PROJECT X — WHY IT STALLED")
b.subtitle("1 quarter · 3 pivots · 12 experiments · 0 shipped")

b.heading("THE PATH IT TOOK")
b.flow(["Idea", "Prototype", "Pivot", "Rebuild", "☠ Shelved"], color="neutral")
b.arrow()

b.columns([
    {"label": "WHAT WENT WRONG", "color": "danger",
     "body": "1  scope kept moving\n2  no owner for delivery\n3  built before validating\n4  metrics were vanity"},
    {"label": "THE NUMBERS", "color": "warn",
     "body": "12 experiments run\n0  shipped to users\n3  full rebuilds\n~$0 revenue"},
])
b.arrow()

b.panel("WHAT TO KEEP", "✓ the data pipeline  -> reuse in Project Y\n~ the UI kit        -> salvage components only\n✗ the v1 backend    -> do not revive", color="good")
b.arrow()

b.panel("RULES CARRIED FORWARD",
        "1  validate demand before building\n2  one owner per deliverable\n3  ship weekly or kill it\n4  measure users, not commits",
        color="action")
b.arrow()

b.node("→ NEXT: one validated bet, shipped in 2 weeks", color="info")

out = os.path.join(os.path.dirname(__file__), "example_board.excalidraw")
print("wrote", b.save(out), "elements ->", out)
