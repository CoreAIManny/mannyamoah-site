# Excalidraw reference — schema, palette, recipes

Read this only when you need to go beyond the `Board` primitives (add a custom element type, match an exact color, or lay something out the helpers don't cover). For normal boards, `SKILL.md` + the library are enough.

## File shape

An `.excalidraw` file is JSON:

```json
{
  "type": "excalidraw",
  "version": 2,
  "source": "https://excalidraw.com",
  "elements": [ /* array of element objects */ ],
  "appState": { "gridSize": 20, "viewBackgroundColor": "#ffffff" },
  "files": {}
}
```

Every element needs a **unique string `id`**. Duplicate ids are the #1 cause of a board that opens blank or with missing shapes — which is why we generate via the library and its `save()` asserts uniqueness.

## Element schema (the fields the library sets)

Common to all elements: `id, type, x, y, width, height, angle, strokeColor, backgroundColor, fillStyle, strokeWidth, strokeStyle, roughness, opacity, groupIds, frameId, roundness, seed, versionNonce, isDeleted, boundElements, updated, link, locked`.

- **rectangle**: as above; `roundness: {"type": 3}` for rounded corners, `null` for sharp.
- **text**: adds `text, fontSize, fontFamily, textAlign, verticalAlign, baseline, containerId, originalText, lineHeight`. Excalidraw re-measures text on load, so approximate `width`/`height` is fine. `containerId: null` keeps text as a free label (not bound inside a shape) — the library keeps labels separate from boxes on purpose, so text never gets clipped.
- **arrow**: adds `points: [[0,0],[dx,dy]]` (relative to the arrow's `x,y`), `startArrowhead, endArrowhead` (`"triangle"` or `null`), `startBinding, endBinding` (`null` = unbound; simplest and robust).

`fillStyle: "hachure"` + `roughness: 1` give the signature hand-sketched look. Set `roughness: 0` and `fillStyle: "solid"` for a crisp, non-sketchy style if the user prefers.

## Fonts

- `fontFamily: 1` — Excalifont / Virgil, the hand-drawn look. Use for **titles and headings**.
- `fontFamily: 2` — Nunito / normal sans.
- `fontFamily: 3` — Cascadia / code (monospace). Use for **body text** — monospace keeps column contents visually aligned.

## Palette (semantic → stroke / background)

| Name | Meaning | Stroke | Background |
|---|---|---|---|
| danger | problems, risks, failures | `#e03131` | `#ffc9c9` |
| danger2 | softer red (banners) | `#e03131` | `#ffe3e3` |
| warn | metrics, watch-items | `#e8590c` | `#ffec99` |
| good | wins, recommendations, keep | `#2f9e44` | `#b2f2bb` |
| info | targets, conclusions | `#1971c2` | `#a5d8ff` |
| action | decisions, rules, next-steps | `#9c36b5` | `#eebefa` |
| neutral | context, timelines, scaffolding | `#495057` | `#f1f3f5` |

Ink (default text): `#1e1e1e`. Muted text (subtitles): `#495057`. Connector arrows: `#343a40`.

Pass a palette name to any helper's `color=`, or an explicit `("#stroke", "#bg")` tuple for custom colors.

## Layout recipes

The library stacks full-width sections top-to-bottom via an internal `y` cursor; `arrow()` draws a connector and adds a gap. Compose these:

- **Autopsy / analysis** (the Core AI board): `title → subtitle → heading + flow(timeline) → arrow → columns(problems | numbers) → arrow → panel(salvage/options) → arrow → panel(rules) → arrow → node(conclusion)`.
- **Roadmap / plan**: `title → flow(phases) → arrow → columns(now | next | later) → arrow → node(goal)`.
- **Decision**: `title → panel(context) → arrow → columns(option A | option B | option C) → arrow → node(recommendation, color="info")`.
- **Before / after**: `title → columns(before="danger" | after="good") → arrow → panel(what changed, color="action")`.
- **Quadrant / 2x2**: not a primitive — draw four rectangles manually via `b._rect(x,y,w,h,stroke,bg)` and four labels via `b._text(...)`, plus two crossing arrows for axes. Use raw coords; `reference.md` schema above covers the fields.

## Escaping / characters

- Use real Unicode in text (`£`, `→`, `✓`, `✗`, `☠`, `⚑`) — write the files with `ensure_ascii=False` (the library does). They render fine in Excalidraw.
- Keep one idea per line; use `\n` inside a body string for multiple lines. Boxes auto-size to the number of lines.

## Extending the library

If you need a shape the helpers don't offer, append to `Board._els` using `self._base(...)` with the right `type` and fields, then call `save()`. Keep using `self._id(prefix)` for ids so uniqueness holds. Prefer adding a reusable method over one-off raw elements if the shape will recur.
